"""
body/executor.py

Handles all filesystem and process-execution side effects. Every operation
is confined to config.settings.WORKSPACE_DIR to prevent path traversal
outside the project, and destructive operations require explicit
confirmation per the rules in config/settings.py.
"""

import os
import subprocess
from dataclasses import dataclass
from typing import Optional

from config import settings


@dataclass
class ExecResult:
    ok: bool
    message: str
    output: str = ""


class ExecutorError(Exception):
    pass


class Executor:
    def __init__(self):
        self.workspace = settings.WORKSPACE_DIR
        os.makedirs(self.workspace, exist_ok=True)

    # -- path safety -----------------------------------------------------
    def _resolve_safe_path(self, filename: str) -> str:
        if not filename:
            raise ExecutorError("No filename provided.")

        candidate = os.path.normpath(os.path.join(self.workspace, filename))
        workspace_abs = os.path.abspath(self.workspace)
        candidate_abs = os.path.abspath(candidate)

        if settings.RULES["restrict_file_ops_to_workspace"]:
            if not candidate_abs.startswith(workspace_abs + os.sep) and candidate_abs != workspace_abs:
                raise ExecutorError(
                    f"Refusing to operate outside workspace directory: {filename}"
                )

        ext = os.path.splitext(candidate_abs)[1]
        if ext not in settings.ALLOWED_EXTENSIONS:
            raise ExecutorError(
                f"Extension '{ext}' not permitted. Allowed: {sorted(settings.ALLOWED_EXTENSIONS)}"
            )

        return candidate_abs

    # -- file operations ---------------------------------------------------
    def create_file(self, filename: str, content: str = "") -> ExecResult:
        try:
            path = self._resolve_safe_path(filename)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return ExecResult(True, f"File created: {os.path.relpath(path, self.workspace)}")
        except (ExecutorError, OSError) as e:
            return ExecResult(False, f"Could not create file: {e}")

    def read_file(self, filename: str) -> ExecResult:
        try:
            path = self._resolve_safe_path(filename)
            if not os.path.exists(path):
                return ExecResult(False, f"File not found: {filename}")
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            max_chars = settings.RULES["max_output_echo_chars"]
            truncated = content[:max_chars]
            suffix = "\n...[truncated]" if len(content) > max_chars else ""
            return ExecResult(True, f"Read {filename}", output=truncated + suffix)
        except (ExecutorError, OSError) as e:
            return ExecResult(False, f"Could not read file: {e}")

    def delete_file(self, filename: str, confirm: bool) -> ExecResult:
        try:
            path = self._resolve_safe_path(filename)
            if not os.path.exists(path):
                return ExecResult(False, f"File not found: {filename}")
            if settings.RULES["require_confirmation_for_destructive_ops"] and not confirm:
                return ExecResult(
                    False,
                    f"Deletion requires confirmation. Re-run as: delete file {filename} confirm",
                )
            os.remove(path)
            return ExecResult(True, f"File deleted: {filename}")
        except (ExecutorError, OSError) as e:
            return ExecResult(False, f"Could not delete file: {e}")

    def list_files(self) -> ExecResult:
        try:
            entries = []
            for root, _, files in os.walk(self.workspace):
                for name in files:
                    rel = os.path.relpath(os.path.join(root, name), self.workspace)
                    entries.append(rel)
            if not entries:
                return ExecResult(True, "Workspace is empty.", output="")
            return ExecResult(True, f"{len(entries)} file(s) in workspace.", output="\n".join(sorted(entries)))
        except OSError as e:
            return ExecResult(False, f"Could not list files: {e}")

    # -- execution ---------------------------------------------------------
    def _run(self, filename: str, ext: str) -> ExecResult:
        try:
            path = self._resolve_safe_path(filename)
            if not os.path.exists(path):
                return ExecResult(False, f"File not found: {filename}")

            binaries = settings.RUNTIME_BINARIES.get(ext)
            if not binaries:
                raise ExecutorError(f"No runtime configured for {ext}")

            last_error: Optional[str] = None
            for binary in binaries:
                try:
                    proc = subprocess.run(
                        [binary, path],
                        cwd=self.workspace,
                        capture_output=True,
                        text=True,
                        timeout=settings.EXEC_TIMEOUT_SECONDS,
                    )
                    max_chars = settings.RULES["max_output_echo_chars"]
                    combined = (proc.stdout or "") + (proc.stderr or "")
                    combined = combined[:max_chars]
                    ok = proc.returncode == 0
                    return ExecResult(
                        ok,
                        f"Executed {filename} (exit code {proc.returncode})",
                        output=combined,
                    )
                except FileNotFoundError:
                    last_error = f"Runtime binary '{binary}' not found on this system."
                    continue
                except subprocess.TimeoutExpired:
                    return ExecResult(False, f"Execution timed out after {settings.EXEC_TIMEOUT_SECONDS}s.")

            return ExecResult(False, last_error or "No suitable runtime found.")
        except ExecutorError as e:
            return ExecResult(False, str(e))

    def run_python(self, filename: str) -> ExecResult:
        return self._run(filename, ".py")

    def run_node(self, filename: str) -> ExecResult:
        return self._run(filename, ".js")
