"""
body/command_parser.py

Turns raw user text into a structured command dict:
    {
        "intent": "create_file" | "run_python" | ... | "unknown",
        "raw": "<original text>",
        "args": {...intent-specific parsed arguments...},
        "confirm": bool,
    }

Parsing is done with plain string matching / regex — no ML, no network.
"""

import re
from typing import Dict, Any

from config import settings


def sanitize(raw_text: str) -> str:
    """Strip control characters and excess whitespace from raw input."""
    if raw_text is None:
        return ""
    text = raw_text.strip()
    # Remove non-printable/control characters (keep normal punctuation).
    text = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text


def _match_intent(text_lower: str) -> str:
    for intent, phrases in settings.COMMAND_MAP.items():
        for phrase in phrases:
            if text_lower.startswith(phrase) or f" {phrase}" in text_lower:
                return intent
    return "unknown"


def _extract_filename(text_lower: str, original: str) -> str:
    """
    Pulls a filename out of a command string. Supports:
      - quoted names: create file "app.py"
      - trailing token: create file app.py
      - 'named X' pattern: create a python file named app.py
    """
    quoted = re.search(r'["\']([^"\']+)["\']', original)
    if quoted:
        return quoted.group(1).strip()

    named = re.search(r"named\s+([^\s]+)", text_lower)
    if named:
        return named.group(1).strip()

    called = re.search(r"called\s+([^\s]+)", text_lower)
    if called:
        return called.group(1).strip()

    # fallback: last whitespace-separated token that looks like a filename
    tokens = original.split()
    for token in reversed(tokens):
        if "." in token and not token.endswith("."):
            return token.strip()

    return ""


def _extract_content(original: str) -> str:
    """
    Extracts inline file content after a 'with content:' or 'containing:' marker.
    If absent, returns an empty string (executor will create an empty/template file).
    """
    match = re.search(r"(?:with content|containing|content)\s*[:\-]\s*(.*)", original, re.IGNORECASE | re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""


def parse(raw_text: str) -> Dict[str, Any]:
    """Main entry point: sanitize + classify + extract arguments."""
    clean = sanitize(raw_text)
    lower = clean.lower()

    confirm = "confirm" in lower
    # Strip the confirm keyword out before further parsing so it doesn't
    # get mistaken for a filename token.
    lower_no_confirm = lower.replace("confirm", "").strip()
    clean_no_confirm = re.sub(r"\bconfirm\b", "", clean, flags=re.IGNORECASE).strip()

    intent = _match_intent(lower_no_confirm)

    args: Dict[str, Any] = {}

    if intent in ("create_file", "read_file", "delete_file", "run_python", "run_node"):
        args["filename"] = _extract_filename(lower_no_confirm, clean_no_confirm)

    if intent == "create_file":
        args["content"] = _extract_content(clean_no_confirm)

    return {
        "intent": intent,
        "raw": raw_text,
        "clean": clean,
        "args": args,
        "confirm": confirm,
    }
