"""
config/settings.py

Central configuration for the local, fully offline, rule-based assistant.
No network calls, no external API keys. Everything here is static config
consumed by brain/ and body/ modules.
"""

import os

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")
WORKSPACE_DIR = os.path.join(BASE_DIR, "workspace")  # all generated/executed files live here

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(WORKSPACE_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# Assistant identity / behavior
# ---------------------------------------------------------------------------
ASSISTANT_NAME = "Ai.personal"
PROMPT_SYMBOL = f"{ASSISTANT_NAME}> "

# Operating rules the brain/executor enforce. These are *safety and scope*
# rules, not personality settings — they keep the assistant fast, predictable,
# and confined to its own workspace instead of the whole filesystem.
RULES = {
    # The assistant only ever reads/writes inside WORKSPACE_DIR. This is a
    # hard boundary, not a preference — it prevents accidental damage to the
    # rest of your machine and keeps the tool safe to run unattended.
    "restrict_file_ops_to_workspace": True,

    # Destructive ops (delete/overwrite) require an explicit "confirm" flag
    # in the same command, e.g. "delete file foo.py confirm".
    "require_confirmation_for_destructive_ops": True,

    # Max characters echoed back from command output, to keep the CLI usable.
    "max_output_echo_chars": 4000,

    # How many turns of conversation to keep in short-term memory.
    "short_term_context_size": 20,
}

# ---------------------------------------------------------------------------
# Command keyword mappings
# Each intent maps to a list of trigger phrases the parser matches against
# (case-insensitive, substring/startswith matching — see command_parser.py).
# ---------------------------------------------------------------------------
COMMAND_MAP = {
    "help": ["help", "commands", "what can you do"],
    "exit": ["exit", "quit", "bye", "stop"],
    "clear_memory": ["clear memory", "reset memory", "forget everything"],
    "show_memory": ["show memory", "show history", "show context"],

    "create_file": ["create file", "make file", "new file", "write file"],
    "read_file": ["read file", "open file", "show file", "cat file"],
    "delete_file": ["delete file", "remove file"],
    "list_files": ["list files", "show files", "list workspace"],

    "run_python": ["run python", "execute python", "run py"],
    "run_node": ["run node", "execute node", "run js", "run javascript"],

    "status": ["status", "system status", "info"],
}

# File extensions the executor is allowed to create/run.
ALLOWED_EXTENSIONS = {".py", ".js", ".json", ".txt", ".md"}

# Runtime binaries used by the executor for scripted languages.
RUNTIME_BINARIES = {
    ".py": ["python3"],
    ".js": ["node"],
}

# Execution timeout (seconds) to prevent runaway processes.
EXEC_TIMEOUT_SECONDS = 15
