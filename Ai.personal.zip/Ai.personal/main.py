#!/usr/bin/env python3
"""
main.py

Entry point for Ai.personal — a fully local, rule-based assistant.
Boots memory, executor, and brain, then runs an interactive CLI loop.

Run:
    python3 main.py
"""

import sys

from config import settings
from brain.memory import Memory
from brain.model_core import Brain
from body.command_parser import parse
from body.executor import Executor

try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init()
    _COLOR = True
except ImportError:
    _COLOR = False


def _print_banner():
    banner = (
        f"\n{settings.ASSISTANT_NAME} — local, offline, rule-based assistant\n"
        f"No external APIs. Workspace: {settings.WORKSPACE_DIR}\n"
        "Type 'help' for commands, 'exit' to quit.\n"
    )
    print(banner)


def _prompt() -> str:
    if _COLOR:
        return f"{Fore.CYAN}{settings.PROMPT_SYMBOL}{Style.RESET_ALL}"
    return settings.PROMPT_SYMBOL


def main():
    memory = Memory()
    executor = Executor()
    brain = Brain(memory=memory, executor=executor)

    _print_banner()

    while True:
        try:
            raw = input(_prompt())
        except (EOFError, KeyboardInterrupt):
            print("\nShutting down.")
            break

        if not raw.strip():
            continue

        try:
            parsed = parse(raw)
            memory.log("user", parsed["clean"])

            response = brain.think(parsed)

            if response == "__EXIT__":
                memory.log("assistant", "Session ended.")
                print("Goodbye.")
                break

            memory.log("assistant", response)
            print(response)

        except Exception as e:  # noqa: BLE001 - top-level guard so the CLI never hard-crashes
            print(f"[error] Unexpected failure: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
