"""
brain/model_core.py

The local "Brain". Takes a parsed command dict from body/command_parser.py,
matches it against known intents/rules, drives body/executor.py for any
filesystem or process actions, and returns a plain-text response.

No neural network, no external model — purely deterministic rule matching.
"""

from typing import Dict, Any

from config import settings
from brain.memory import Memory
from body.executor import Executor, ExecResult


class Brain:
    def __init__(self, memory: Memory, executor: Executor):
        self.memory = memory
        self.executor = executor

    # -- top-level dispatch -----------------------------------------------
    def think(self, parsed: Dict[str, Any]) -> str:
        intent = parsed["intent"]
        args = parsed["args"]
        confirm = parsed["confirm"]

        handler = getattr(self, f"_handle_{intent}", None)
        if handler is None:
            return self._handle_unknown(parsed)

        return handler(args, confirm)

    # -- intent handlers ----------------------------------------------------
    def _handle_help(self, args, confirm) -> str:
        lines = [f"{settings.ASSISTANT_NAME} — local rule-based assistant. Available commands:"]
        for intent, phrases in settings.COMMAND_MAP.items():
            lines.append(f"  - {intent}: e.g. \"{phrases[0]}\"")
        lines.append('File ops: create file "name.py" with content: <code>')
        lines.append("Destructive ops (delete) need the word 'confirm' in the command.")
        return "\n".join(lines)

    def _handle_exit(self, args, confirm) -> str:
        return "__EXIT__"

    def _handle_clear_memory(self, args, confirm) -> str:
        self.memory.clear()
        return "Short-term and persisted memory cleared."

    def _handle_show_memory(self, args, confirm) -> str:
        context = self.memory.short_term_context()
        if not context:
            return "No conversation history yet."
        lines = [f"[{c['timestamp']}] {c['role']}: {c['text']}" for c in context]
        return "\n".join(lines)

    def _handle_status(self, args, confirm) -> str:
        turns = len(self.memory.full_history())
        return (
            f"{settings.ASSISTANT_NAME} status: online (local, offline mode)\n"
            f"Workspace: {settings.WORKSPACE_DIR}\n"
            f"Logged turns: {turns}"
        )

    def _handle_create_file(self, args, confirm) -> str:
        filename = args.get("filename", "")
        content = args.get("content", "")
        if not filename:
            return "I need a filename. Example: create file \"app.py\" with content: print('hi')"
        result: ExecResult = self.executor.create_file(filename, content)
        return result.message

    def _handle_read_file(self, args, confirm) -> str:
        filename = args.get("filename", "")
        if not filename:
            return "I need a filename. Example: read file app.py"
        result = self.executor.read_file(filename)
        if result.ok:
            return f"{result.message}\n---\n{result.output}"
        return result.message

    def _handle_delete_file(self, args, confirm) -> str:
        filename = args.get("filename", "")
        if not filename:
            return "I need a filename. Example: delete file app.py confirm"
        result = self.executor.delete_file(filename, confirm)
        return result.message

    def _handle_list_files(self, args, confirm) -> str:
        result = self.executor.list_files()
        if result.output:
            return f"{result.message}\n{result.output}"
        return result.message

    def _handle_run_python(self, args, confirm) -> str:
        filename = args.get("filename", "")
        if not filename:
            return "I need a filename. Example: run python app.py"
        result = self.executor.run_python(filename)
        status = "OK" if result.ok else "FAILED"
        return f"{result.message} [{status}]\n{result.output}"

    def _handle_run_node(self, args, confirm) -> str:
        filename = args.get("filename", "")
        if not filename:
            return "I need a filename. Example: run node app.js"
        result = self.executor.run_node(filename)
        status = "OK" if result.ok else "FAILED"
        return f"{result.message} [{status}]\n{result.output}"

    def _handle_unknown(self, parsed: Dict[str, Any]) -> str:
        return (
            "I didn't match that to a known command. Type 'help' to see "
            "what I can do (file create/read/delete/list, run python/node, "
            "memory commands, status)."
        )
