"""
brain/memory.py

Local, file-backed conversation memory. No external storage — a single
JSON file on disk under data/memory.json. Keeps a short-term rolling
context window plus a full persisted history log.
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Any

from config import settings


class Memory:
    """Manages conversation history and short-term state for the assistant."""

    def __init__(self, memory_file: str = settings.MEMORY_FILE):
        self.memory_file = memory_file
        self.short_term_limit = settings.RULES["short_term_context_size"]
        self.history: List[Dict[str, Any]] = []
        self.state: Dict[str, Any] = {}
        self._load()

    # -- persistence ---------------------------------------------------
    def _load(self) -> None:
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.history = data.get("history", [])
                    self.state = data.get("state", {})
            except (json.JSONDecodeError, OSError):
                # Corrupt or unreadable memory file — start fresh rather
                # than crashing the assistant.
                self.history = []
                self.state = {}
        else:
            self.history = []
            self.state = {}

    def _save(self) -> None:
        try:
            with open(self.memory_file, "w", encoding="utf-8") as f:
                json.dump(
                    {"history": self.history, "state": self.state},
                    f,
                    indent=2,
                    ensure_ascii=False,
                )
        except OSError as e:
            print(f"[memory] warning: could not persist memory file: {e}")

    # -- conversation log ------------------------------------------------
    def log(self, role: str, text: str) -> None:
        """Append a turn to history and persist it."""
        entry = {
            "role": role,  # "user" or "assistant"
            "text": text,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
        }
        self.history.append(entry)
        self._save()

    def short_term_context(self) -> List[Dict[str, Any]]:
        """Return the most recent N turns for local reasoning context."""
        return self.history[-self.short_term_limit:]

    def full_history(self) -> List[Dict[str, Any]]:
        return self.history

    def clear(self) -> None:
        self.history = []
        self.state = {}
        self._save()

    # -- key/value scratch state -----------------------------------------
    def set_state(self, key: str, value: Any) -> None:
        self.state[key] = value
        self._save()

    def get_state(self, key: str, default: Any = None) -> Any:
        return self.state.get(key, default)
